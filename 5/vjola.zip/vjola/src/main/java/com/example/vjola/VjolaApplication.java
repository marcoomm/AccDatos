package com.example.vjola;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VjolaApplication {

	public static void main(String[] args) {
		SpringApplication.run(VjolaApplication.class, args);
	}

}
