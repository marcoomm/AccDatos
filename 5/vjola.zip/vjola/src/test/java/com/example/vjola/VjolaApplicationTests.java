package com.example.vjola;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VjolaApplicationTests {

	@Test
	void contextLoads() {
	}

}
